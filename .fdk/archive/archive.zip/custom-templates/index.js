import Example from "./example.vue";

export default {
    testpage: {
        component: Example,
        header: false,
        footer: false
    }
};